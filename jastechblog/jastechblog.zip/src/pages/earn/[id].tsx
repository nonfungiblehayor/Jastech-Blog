import EachEarningPage from "@/components/Earn/EachEarningPage";
import { NextPageWithLayout } from "../_app";

const EarningPage: NextPageWithLayout = () => {
  return (
    <div>
      <EachEarningPage />
    </div>
  );
};
export default EarningPage;
