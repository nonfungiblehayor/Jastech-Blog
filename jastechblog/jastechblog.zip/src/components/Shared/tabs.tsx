export const sportTabs = [
  {
    text: "Football",
    color: "#A56CBD",
  },
  {
    text: "Basketball",
    color: "#08F",
  },
  {
    text: "Cricket",
    color: "#49EFC8",
  },
  {
    text: "Tennis",
    color: "#2ECC71",
  },
  {
    text: "Formular1",
    color: "#997C00",
  },
  {
    text: "Boxing",
    color: "#08F",
  },
];
export const movieTabs = [
  {
    text: "Action",
    color: "#F65050",
  },
  {
    text: "Animation",
    color: "#A56CBD",
  },
  {
    text: "Bollywood",
    color: "#08F",
  },
  {
    text: "K-drama",
    color: "#49EFC8",
  },
  {
    text: "Nollywood",
    color: "#2ECC71",
  },
  {
    text: "Sci-fi",
    color: "#997C00",
  },
  {
    text: "Tv-Series",
    color: "#08F",
  },
];
