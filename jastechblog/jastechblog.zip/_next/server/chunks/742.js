"use strict";exports.id=742,exports.ids=[742],exports.modules={6086:(e,t,i)=>{i.d(t,{Z:()=>__WEBPACK_DEFAULT_EXPORT__});var n=i(997),r=i(7518),s=i.n(r);let o=s().div.withConfig({componentId:"sc-434d37a2-0"})`
    width: 100%;
    align-items: center;
    justify-content: center;
    button {
        width: 83vw;
        border-radius: 8px;
        height: 46px;
        text-align: center;
        background-color: #f65050;
        color: #fff;
        font-size: 18px;
        font-weight: 500;
        align-self: center;
        margin: auto;
        margin-top: 20px;
        border: none;
    }
`,__WEBPACK_DEFAULT_EXPORT__=({label:e,onClick:t,className:i})=>n.jsx(o,{children:n.jsx("div",{className:"flex-row",children:n.jsx("button",{className:i,onClick:t,children:e})})})},4581:(e,t,i)=>{i.d(t,{Z:()=>__WEBPACK_DEFAULT_EXPORT__});var n=i(997),r=i(5675),s=i.n(r);let __WEBPACK_DEFAULT_EXPORT__=()=>n.jsx("div",{children:n.jsx(s(),{src:"/img/spinner.gif",alt:"spinner",width:200,height:200})})}};